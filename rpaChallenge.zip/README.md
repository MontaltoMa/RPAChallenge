<H1>RPA Challenge </H1>

<p> Desafio realizado utilizando BotCity e Pandas! </p>

<p>Objetivo era acessar o site https://rpachallenge.com/ baixar o arquivo excel, ler este arquivo e preencher as informações nos campos do site, porem os campos sempre alteram de lugar quando um é preenchido</p>


