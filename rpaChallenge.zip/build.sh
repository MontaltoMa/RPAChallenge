#!/bin/bash

zip -r "rpaChallenge.zip" * -x "rpaChallenge.zip"